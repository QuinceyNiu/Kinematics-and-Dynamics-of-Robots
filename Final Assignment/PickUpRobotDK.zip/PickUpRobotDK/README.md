# Pick_up_roboDK
## The simulation contains the following items:

1. ### Sensory simulation (such as a camera)

2. ### Decision making (given randomized conditions)

3. ### **An API interface in any programming language(Python), with appropriate high-level functionality**

4. ### Multiple robotic arms working simultaneously

5. ### Imported external parts (not from RoboDK)

## Image Processing

### Camera Raw Image
![Logo](Image-Camera-Simulation.png)

### Scale Down Input
![Logo](vision_visu_1_input.png)

### Add Gaussian Blur
![Logo](vision_visu_2_blur.png)

### Convert to Grayscale
![Logo](vision_visu_3_gray.png)

### Inverted Binary Thresholding
![Logo](vision_visu_4_thresh.png)

### Trace Contours, Add Discrete Colors to each Contour Object, Estimate Polygon, Use Polygon Corners to Calculate Orientation, Use Homography Transform to get World Coordinates from Pixel Coordinates
![Logo](vision_visu_5_output.png)

### Full Visu
![Logo](vision_visu.png)

### Initial Calibration is being done by using 4 additional red bricks with knows world locations.
![Logo](mono_camera_frame-Snapshot_Calibration.png)



## Video presentation：

<video src="/Users/quinceyniu/Desktop/Programming/pick_up_roboDK/robot_vision.mp4"></video>
